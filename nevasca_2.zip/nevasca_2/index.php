<?php
require_once 'cleanup.php';
header('Location: views/vendas.php');
exit();
?>